
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h2 class="mt-4">Subir evidencia de la tarea</h2>
            <div align="right">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary btn-sm">Regresar</a>
              </div>
              <br>
                <?php if($message = Session::get('success')): ?>
                <ol class="breadcrumb mb-4">
                  <li class="breadcrumb-item"> <?php echo e($message); ?></li>
                </ol>
                <?php endif; ?>
            <div class="row">
                  <div class="col-md-12">
                  <ul class="list-group">
                    <?php if(date('Y-m-d') > $tarea->fecha_plazo): ?>
                    <li class="list-group-item"><b>Lo sentimos mucho esta tarea ya cumplió su plazo de entrega.</b></li>
                    <?php else: ?>

                      <li class="list-group-item"><b>Nombre: </b> <?php echo e($tarea->nombre_tarea); ?></li>
                      <li class="list-group-item"><b>Descripción:  </b> <?php echo e($tarea->descripcion_tarea); ?></li>
                      <li class="list-group-item"><b>Vence:  </b> <?php echo e(date('d-M-Y', strtotime($tarea->fecha_plazo))); ?></li>
                        <li class="list-group-item"><b>Estado: </b> <?php if(date('Y-m-d') > $tarea->fecha_plazo): ?> Vencida <?php else: ?> Activa <?php endif; ?></li>
                        <li class="list-group-item"><b>Materia: </b> <?php echo e(!empty($tarea->materia) ? $tarea->materia->nombre:'?'); ?></li>
                        <li class="list-group-item"><b>Profesor: </b> <?php echo e(!empty($tarea->profesor) ? $tarea->profesor->nombre:'?'); ?></li>
                        <?php if($check != ''): ?>
                        <li class="list-group-item"><b>Evidencia: </b> <a download="<?php echo e($check->evidencia); ?>" href="<?php echo e(URL::to('/')); ?>/EvidenciasTareas/<?php echo e($check->evidencia); ?>">Descargar</a><br>
                           <object data="<?php echo e(URL::to('/')); ?>/EvidenciasTareas/<?php echo e($check->evidencia); ?>" width="100" height="100"></object>
                        </li>
                        <?php endif; ?>
                      <li class="list-group-item">
                        <?php if(date('Y-m-d') <= $tarea->fecha_plazo): ?>
                        <?php if($check != ''): ?>
                        <form method="post" enctype="multipart/form-data" action="<?php echo e(route('tareas.actualizar', $check->id)); ?>">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('PATCH'); ?>
                          <div class="form-row">
                            <div class="form-group col-md-6">
                            <label for="evidencia">Seleccione un archivo</label>
                            <br>
                            <input type="file" class="form-control" id="evidencia" name="evidencia" required value="<?php echo e(URL::to('/')); ?>/EvidenciasTareas/<?php echo e($check->evidencia); ?>">
                            <input type="hidden" name="hidden_file" value="<?php echo e($check->evidencia); ?>" />
                            <button type="submit" name="add" value="Add" class="btn btn-success">Actualizar evidencia</button><br>
                            <input type="hidden" name="url" value="<?php echo e(url()->current()); ?>">
                            </div>
                          </div>
                          <?php else: ?>

                        <form method="post" enctype="multipart/form-data" action="<?php echo e(route('tareas.enviar')); ?>">
                            <?php echo csrf_field(); ?>
                          <div class="form-row">
                            <div class="form-group col-md-6">
                         <input type="hidden" name="tarea_id" value="<?php echo e($tarea->id_tarea); ?>">
                         <input type="hidden" name="alumno_id" value="<?php echo e(auth()->user()->alumno_id); ?>">
                            <label for="evidencia">Seleccione un archivo</label>
                            <input type="file" class="form-control" id="evidencia" name="evidencia" required>
                            <button type="submit" name="add" value="Add" class="btn btn-success">Subir evidencia</button>
                            <input type="hidden" name="url" value="<?php echo e(url()->current()); ?>">
                            </div>
                          </div>
                          </form>
                          <?php endif; ?>
                        </form>
                      <?php endif; ?>
                      </li>
                      <?php endif; ?>
                    </ul>

                  </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Programium\resources\views/Tareas/detalles_subir.blade.php ENDPATH**/ ?>