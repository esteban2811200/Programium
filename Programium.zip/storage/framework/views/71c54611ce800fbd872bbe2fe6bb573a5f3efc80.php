
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h2 class="mt-4"><?php if(auth()->guard()->check()): ?> <?php if(auth()->user()->role != 'administrador'): ?> Tus Tareas <?php else: ?> Listado de materias <?php endif; ?> <?php endif; ?></h2>
            <div align="right">
              <?php if(auth()->guard()->check()): ?>
              <?php if(auth()->user()->role == 'profesor'): ?>
                <a href="<?php echo e(route('tareas.create')); ?>" class="btn btn-primary btn-sm">Agregar Tarea</a>
                <?php endif; ?>
                <?php endif; ?>
              </div>
              <br>
                <?php if($message = Session::get('success')): ?>
                <ol class="breadcrumb mb-4">
                  <li class="breadcrumb-item active">Tareas:  <?php echo e($message); ?></li>
                </ol>
                <?php endif; ?>
            <div class="row">
                <div class="table-responsive">
                  <table class="table table-bordered table-bordered dataTable"  width="100%" cellspacing="0">
                      <thead class="thead-dark">
                      <tr>
                      <th>Nombre</th>
                      <th>Descripcion</th>
                      <th>Fecha</th>
                      <th>Curso</th>
                      <th></th>
                      </tr>
                      </thead>
                      <tbody>
                    <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($row->nombre_tarea); ?></td>
                    <td><?php echo e($row->descripcion_tarea); ?></td>
                    <td><?php echo e($row->fecha_plazo); ?></td>
                    <th><?php echo e(!empty($row->curso) ? $row->curso->nombre:'?'); ?></th>
                    <td>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role == 'profesor'): ?>
                    <form action="<?php echo e(route('tareas.destroy', $row->id_tarea)); ?>" method="post">
                    <a href="<?php echo e(route('tareas.show', $row->id_tarea)); ?>" class="btn btn-primary btn-sm">Ver</a>
                    <a href="<?php echo e(route('tareas.edit', $row->id_tarea)); ?>" class="btn btn-warning btn-sm">Editar</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm">Borrar</button>
                    </form>
                    <?php endif; ?>
                    <?php endif; ?>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Programium\resources\views/Tareas/tareas.blade.php ENDPATH**/ ?>