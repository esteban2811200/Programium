
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h2 class="mt-4">Asignar Materia a un Alumno</h2>
            <div align="right">
                <a href="<?php echo e(route('alumnos.index')); ?>" class="btn btn-default btn-sm">Regresar</a>
              </div>
                <?php if($message = Session::get('respuesta')): ?>
                <ol class="breadcrumb mb-4">
                  <li class="breadcrumb-item active"><?php echo e($message); ?></li>
                </ol>
                <?php endif; ?>
              <br>
            <div class="row">
              <div class="col">
            <form method="post" action="<?php echo e(route('alumnos.relacionar_materias')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="profesor_id">Listado de Alumnos</label>
                            <select class="form-control" id="alumno_id" name="alumno_id">
                                <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($a->id); ?>"><?php echo e($a->nombre); ?> <?php echo e($a->apellidos); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="materia_id">Listado de Materias</label>
                            <select class="form-control" id="materia_id" name="materia_id">
                                <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($m->id); ?>"><?php echo e($m->nombre); ?> <?php echo e($m->descripcion); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    </div>
                   <button type="submit" name="add" value="Add" class="btn btn-primary">Agregar</button>
                </form>
              </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Programium\resources\views/Alumnos/asignar_materias.blade.php ENDPATH**/ ?>