
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h2 class="mt-4">Listado de Profesores</h2>
            <div align="right">
                <a href="<?php echo e(route('profesores.create')); ?>" class="btn btn-primary btn-sm">Agregar profesor</a>
              </div>
              <br>
                <?php if($message = Session::get('success')): ?>
                <ol class="breadcrumb mb-4">
                  <li class="breadcrumb-item active">Profesores:  <?php echo e($message); ?></li>
                </ol>
                <?php endif; ?>
            <div class="row">
                <div class="table-responsive">
                  <table class="table table-bordered table-bordered dataTable"  width="100%" cellspacing="0">
                      <thead class="thead-dark">
                      <tr>
                      <th>Nombre</th>
                      <th>Titulo</th>
                      <th>Correo/Usuario</th>
                      <th>Opciones</th>
                      </tr>
                      </thead>
                      <tbody>
                    <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($row->nombre); ?></td>
                    <td><?php echo e($row->titulo); ?></td>
                    <td><?php echo e(!empty($row->user) ? $row->user->email:'?'); ?></td>
                    <td>
                    <form action="<?php echo e(route('profesores.destroy', $row->id_profe)); ?>" method="post">
                    <a href="<?php echo e(route('profesores.show', $row->id_profe)); ?>" class="btn btn-primary btn-sm">Ver</a>
                    <a href="<?php echo e(route('profesores.edit', $row->id_profe)); ?>" class="btn btn-warning btn-sm">Editar</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm">Borrar</button>
                    </form>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Programium\resources\views/Profesores/profesores.blade.php ENDPATH**/ ?>