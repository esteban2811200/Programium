
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h2 class="mt-4">Foro de discución</h2>
            <div align="right">
                <a href="<?php echo e(route('foro.index')); ?>" class="btn btn-primary btn-sm">Regresar</a>
              </div>
              <br>
                <?php if($message = Session::get('success')): ?>
                <ol class="breadcrumb mb-4">
                  <li class="breadcrumb-item active">Cursos:  <?php echo e($message); ?></li>
                </ol>
                <?php endif; ?>
            <div class="row">
                  <div class="col-md-12">


                  </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Programium\resources\views/Foro/ver.blade.php ENDPATH**/ ?>