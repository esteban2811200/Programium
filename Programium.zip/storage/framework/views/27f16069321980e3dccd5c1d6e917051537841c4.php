
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h2 class="mt-4"><?php if(auth()->guard()->check()): ?> <?php if(auth()->user()->role != 'administrador'): ?> Tus materias <?php else: ?> Listado de materias <?php endif; ?> <?php endif; ?></h2>
            <div align="right">
              <?php if(auth()->guard()->check()): ?>
              <?php if(auth()->user()->role == 'administrador'): ?>
                <a href="<?php echo e(route('materias.create')); ?>" class="btn btn-primary btn-sm">Agregar Materia</a>
                <?php endif; ?>
                <?php endif; ?>
              </div>
              <br>
                <?php if($message = Session::get('success')): ?>
                <ol class="breadcrumb mb-4">
                  <li class="breadcrumb-item active">Materias:  <?php echo e($message); ?></li>
                </ol>
                <?php endif; ?>
            <div class="row">
                <div class="table-responsive">
                  <table class="table table-bordered table-bordered dataTable"  width="100%" cellspacing="0">
                      <thead class="thead-dark">
                      <tr>
                      <th>nombre</th>
                      <th>descripcion</th>
                      <th>estado</th>
                      <th></th>
                      </tr>
                      </thead>
                      <tbody>
                    <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($row->nombre); ?></td>
                    <td><?php echo e($row->descripcion); ?></td>
                    <td><?php if($row->estado == 0): ?>Inactivo <?php else: ?> Activo <?php endif; ?></td>
                    <td>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role == 'administrador'): ?>
                    <form action="<?php echo e(route('materias.destroy', $row->id_mater)); ?>" method="post">
                    <a href="<?php echo e(route('materias.show', $row->id_mater)); ?>" class="btn btn-primary btn-sm">Ver</a>
                    <a href="<?php echo e(route('materias.edit', $row->id_mater)); ?>" class="btn btn-warning btn-sm">Editar</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm">Borrar</button>
                    </form>
                    <?php endif; ?>
                    <?php endif; ?>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Programium\resources\views/Materias/materias.blade.php ENDPATH**/ ?>