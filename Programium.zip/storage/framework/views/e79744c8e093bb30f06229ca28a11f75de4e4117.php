
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h2 class="mt-4">Iniciar un foro</h2>
            <div align="right">
                <a href="<?php echo e(route('foro.index')); ?>" class="btn btn-default btn-sm">Regresar</a>
              </div>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
              <br>
            <div class="row">
              <div class="col">
            <form method="post" action="<?php echo e(route('foro.index')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label for="contenido">Iniciar el foro</label>
                            <textarea class="form-control" name="contenido" id="contenido" placeholder="Escribe un mensaje para el curso."></textarea>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="archivo">Subir un archivo</label>
                            <input type="file" name="archivo" id="archivo">
                        </div>
                    </div>
                    <input type="hidden" name="curso" id="curso" value="<?php echo e($curso->id_curso); ?>">
                   <button type="submit" name="add" value="Add" class="btn btn-primary">Enviar</button>
                </form>
              </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Programium\resources\views/Foro/crear.blade.php ENDPATH**/ ?>