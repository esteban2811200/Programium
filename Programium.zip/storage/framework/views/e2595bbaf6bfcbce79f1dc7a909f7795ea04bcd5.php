
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h2 class="mt-4">Foro | <?php echo e($curso->nombre); ?></h2>

              <br>
                <?php if($message = Session::get('success')): ?>
                <ol class="breadcrumb mb-4">
                  <li class="breadcrumb-item active"><?php echo e($message); ?></li>
                </ol>
                <?php endif; ?>
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                <h5 class="card-header"><?php echo e($curso->nombre); ?></h5>
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($foro->contenido); ?></h5>
                  <p class="card-text">Publicado: <a href=""><?php echo e(date('d-m-Y H:m', strtotime($foro->created_at))); ?> Por: <a href="#"><?php echo e($profesor->nombre); ?></a> </p>
                  <?php if($foro->archivo != ''): ?>
                  <a class="btn btn-primary" download="descarga" href="<?php echo e(URL::to('/')); ?>/ForoFiles/<?php echo e($foro->archivo); ?>">Descargar</a>
                  <?php endif; ?>
                  <div align="right">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#responder">
                  Responder
                </button>
                  </div>
                </div>
              </div>
                <?php echo $__env->make('Foro.ModalResponder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
                <div class="col-md-12">
                
                <?php if($respuestas != ''): ?>
                <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="card">
                  <div class="card-header">
                    <?php echo e($r->user->name); ?>

                  </div>
                  <div class="card-body">
                    <blockquote class="blockquote mb-0">
                      <p><?php echo e($r->contenido_r); ?></p>
                      <footer class="blockquote-footer">Publicado <cite title="Source Title"><?php echo e(date('d-m-Y H:m', strtotime($foro->created_at))); ?></cite></footer>
                    </blockquote>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Programium\resources\views/Foro/foro.blade.php ENDPATH**/ ?>