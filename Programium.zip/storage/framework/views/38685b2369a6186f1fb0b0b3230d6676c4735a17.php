
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h2 class="mt-4">Entrega de la tarea: <b><?php echo e($tarea->nombre_tarea); ?></b></h2>
            <div align="right">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary btn-sm">Regresar</a>
              </div>
              <br>


            <div class="row">
                  <div class="col-md-12">
                  <table class="table table-hover">
                      <thead>
                      <tr>
                      <th>Alumno</th>
                      <th>Estado de entrega</th>
                      <th>Evidencia</th>
                      </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $entrega; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($q->nombre); ?> <?php echo e($q->apellidos); ?></td>
                        <td>Entregado</td>
                        <td><a download="Evidencia<?php echo e($q->evidencia); ?>" href="<?php echo e(URL::to('/')); ?>/EvidenciasTareas/<?php echo e($q->evidencia); ?>" class="btn btn-default">Descargar</a></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>

                  </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Programium\resources\views/Tareas/ver_completados_tarea.blade.php ENDPATH**/ ?>